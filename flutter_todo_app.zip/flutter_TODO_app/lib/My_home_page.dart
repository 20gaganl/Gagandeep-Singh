import 'package:flutter/material.dart';
import 'package:flutter_todo_app/Dart_data.dart';
import '_todo_card_widget.dart';
import '_todo_model.dart';





class MyHomePage extends StatelessWidget {
  const MyHomePage({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      floatingActionButton: FloatingActionButton(
        onPressed: () {
          Navigator.push(
            context,
            MaterialPageRoute(
                builder: (child) => const NewTaskPage()
            ),
          );
        },
        child: const Icon(Icons.add),
      ),
      appBar: AppBar(
        title: const Text("TODO: Pending"),
        actions: [
          PopupMenuButton(
            itemBuilder: (context) => popUpMenuItemTitleList
                .map((e) => PopupMenuItem(
              child: Text(
                e,
              ),
            ))
                .toList(),
          ),
        ],
      ),
      body: ListView(
        children: [
          Todocardwidget(
            todoModel: TodoModel(
                duedate: "2023-05-01",
                status: false,
                taskname: "Task Name",
                type: "Shopping"),
          ),
          Todocardwidget(
            todoModel: TodoModel(
                duedate: "2023-05-01",
                status: true,
                taskname: "Task Name",
                type: "Work"),
          ),
          Todocardwidget(
            todoModel: TodoModel(
                duedate: "2023-05-01",
                status: false,
                taskname: "Task Name",
                type: "Personal"),
          ),
          Todocardwidget(
            todoModel: TodoModel(
                duedate: "2023-05-01",
                status: false,
                taskname: "Task Name",
                type: "Wishlist"),
          ),
        ],
      ),
    );
  }
}