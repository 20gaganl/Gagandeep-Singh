import 'package:flutter/material.dart';

import 'TODO_model.dart';

class Todocardwidget extends StatelessWidget {
  final TodoModel todoModel;

  const Todocardwidget({
    Key? key,
    required this.todoModel,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Card(
      child: ListTile(
        leading: Checkbox(
          onChanged: (value) {
          },
          value: todoModel.status,
        ),
        title: Text(todoModel.taskname),
        subtitle: Text(
          todoModel.duedate,
          style: const TextStyle(
            color: Colors.blue,
            fontWeight: FontWeight.bold,
          ),
        ),
        trailing: Text(
          todoModel.type,
          style: TextStyle(
              color: todotypecolor(todoModel.type),
              fontSize: 20,
              fontWeight: FontWeight.bold),
        ),
      ),
    );
  }
}

todotypecolor(String value) {
  switch (value) {
    case "Shopping":
      return Colors.amber;
    case "Work":
      return Colors.blue;
    case "Personal":
      return Colors.red;
    case "Wishlist":
      return Colors.orange;
    default:
      return Colors.black;
  }
}
