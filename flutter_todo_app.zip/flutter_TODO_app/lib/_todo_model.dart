class TodoModel {
  final String taskname;
  final String duedate;
  final String type;
  final bool status;
  TodoModel({
    required this.duedate,
    required this.status,
    required this.taskname,
    required this.type,
  });
}